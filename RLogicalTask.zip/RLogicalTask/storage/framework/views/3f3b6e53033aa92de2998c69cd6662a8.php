
<?php $__env->startSection('title','Cart Items'); ?>
<?php $__env->startSection('content'); ?>
  <table class="table" id="productTable">
    <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Product</th>
            <th scope="col">Image</th>
            <th scope="col">Price</th>
            <th scope="col">Quantity</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
  </table>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
       $(document).ready(function() {
        $('#productTable').DataTable({
            processing: true,
            serverSide: true,
            "ajax": {
                "url": "<?php echo e(route('frontent.carditem')); ?>",
                "type": "GET"
            },  
            columns: [
                { 
                    data: 'DT_RowIndex', name: '', orderable: true, searchable: false
                },
                { data: 'name', name: 'name' },
                { data: 'image', name: 'image' },
                { data: 'price', name: 'price' },
                { data: 'qty', name: 'qty' },
            ]
        });
       });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontent_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RLogicalTask\resources\views/card_item/index.blade.php ENDPATH**/ ?>