
<?php $__env->startSection('title','Front Users'); ?>
<?php echo $__env->yieldContent('header-css'); ?>
<style>
    * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
        }

        .container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }

        .product-card {
            border: 1px solid #ccc;
            border-radius: 5px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .product-card:hover {
            transform: translateY(-5px);
        }

        .product-image {
            width: 100%;
            height: 200px;
            background-color: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #999;
            font-size: 18px;
        }

        .product-details {
            padding: 15px;
            text-align: center;
        }

        .product-title {
            font-size: 16px;
            margin: 10px 0;
            color: #333;
        }

        .product-price {
            font-size: 18px;
            font-weight: bold;
            color: #1a73e8;
        }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    
    
    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php if($product['categories']): ?>
            <?php $__empty_2 = true; $__currentLoopData = $product['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                <div class="product-card">
                    <div class="product-image">
                        <img src="<?php echo e(Storage::url($category->image)); ?>" style="height: 100px; width: 100px">
                    </div>
                    <div class="product-details">
                        <div class="product-title"><?php echo e(!empty($product->name) ? $product->name : ''); ?></div>
                        <div class="product-price">Price: <?php echo e(!empty($product->price) ?  $product->price : ''); ?></div>
                        <p>
                            <?php echo e(!empty($product->description) ?  $product->description : ''); ?>

                        </p>
                        
                        <button type="button" class="btn btn-primary add_to_cart" data-category_id="<?php echo e(!empty($category->id) ?  $category->id : ''); ?>" data-product_id="<?php echo e(!empty($product->id) ?  $product->id : ''); ?>">Add to Cart</button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                
            <?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
       $(document).ready(function() {
            $(document).on('click','.add_to_cart',function(e) {
              e.preventDefault();
              const self = $(this);
              const product_id = self.data('product_id');
              const category_id = self.data('category_id');
              $.ajax({
                  url: "<?php echo e(route('frontent.addtocart')); ?>",
                  type: "POST",
                  dataType: "JSON",
                  data: {
                    product_id: product_id,
                    category_id: category_id,
                  },
                  success: function(response) {
                      if(response.status) {
                          successToastMsg(response.message);
                          window.location.href = "<?php echo e(route('frontent.dashboard')); ?>";
                      } else {
                          toastFailedMsg(response.message)
                      }
                  },
                  error: function(response) {
                      toastFailedMsg(response.responseJSON.message)
                  }
              });
            });

            function successToastMsg(message) {
              Toastify({
                  text: message,
                  duration: 3000,
                  destination: "https://github.com/apvarun/toastify-js",
                  newWindow: true,
                  close: true,
                  gravity: "top",
                  position: "right",
                  stopOnFocus: true,
                  style: {
                      background: "linear-gradient(to right, #00b09b, #96c93d)"
                  },
              }).showToast();
            }

            function toastFailedMsg(message) {
                Toastify({
                    text: message,
                    duration: 3000,
                    destination: "https://github.com/apvarun/toastify-js",
                    newWindow: true,
                    close: true,
                    gravity: "top",
                    position: "right",
                    stopOnFocus: true,
                    style: {
                        background: "linear-gradient(98.3deg, rgb(0, 0, 0) 10.6%, rgb(255, 0, 0) 97.7%)"
                    },
                }).showToast();
            }
       });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontent_layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RLogicalTask\resources\views/frontent/dashboard.blade.php ENDPATH**/ ?>