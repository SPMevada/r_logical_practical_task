<?php echo csrf_field(); ?>
<div class="mb-3">
    <label for="name" class="form-label">Title<span class="text-danger">*</span></label>
    <input type="text" name="name" placeholder="Please enter category name" value="<?php echo e(!empty($category->name) ? $category->name : ''); ?>" class="form-control" aria-describedby="emailHelp">
</div>
<div class="mb-3">
    <label for="description" class="form-label">Description<span class="text-danger">*</span></label>
    <textarea class="form-control" name="description" id="" cols="30" rows="2" placeholder="Please enter description"><?php echo e(!empty($category->description) ? $category->description : ''); ?></textarea>
</div>
<div class="mb-3">
    <label for="image" class="form-label">Image <span class="text-danger">*</span></label>
    <div class="input-group">
        <input type="file" class="form-control" id="image" name="image" accept="image/*" aria-label="Upload">
    </div>
    <input type="hidden" name="check_image" value="<?php echo e(!empty($category->image) ? $category->image : ''); ?>">
</div>

<input type="hidden" name="category_id" value="<?php echo e(!empty($category->id) ? $category->id : ''); ?>">
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-primary">Submit</button>
</div><?php /**PATH C:\xampp\htdocs\RLogicalTask\resources\views/categories/form.blade.php ENDPATH**/ ?>