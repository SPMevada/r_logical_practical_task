<?php echo csrf_field(); ?>
<input type="hidden" name="product_id" value="<?php echo e(!empty($product->id) ? $product->id : ''); ?> " /> 
<div class="mb-3">
    <label for="name" class="form-label">Title<span class="text-danger">*</span></label>
    <input type="text" name="name" placeholder="Please enter product name" value="<?php echo e(!empty($product->name) ? $product->name : ''); ?>" class="form-control" aria-describedby="emailHelp">
</div>
<div class="mb-3">
    <label for="description" class="form-label">Description<span class="text-danger">*</span></label>
    <textarea class="form-control" name="description" id="" cols="30" rows="2" placeholder="Please enter description"><?php echo e(!empty($product->description) ? $product->description : ''); ?></textarea>
</div>
<div class="mb-3">
    <label for="categories" class="form-label">Categories <span class="text-danger">*</span></label>
    <select class="form-select select2" id="category" name="categories[]"  multiple tyle="width: 100%;">
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($category->id); ?>" 
                <?php echo e((!empty($product_category) && in_array($category->id, array_column($product_category, 'category_id'))) ? 'selected' : ''); ?>>
                <?php echo e($category->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option >No categories available</option>
        <?php endif; ?>
    </select>
</div>
<div class="mb-3">
    <label for="name" class="form-label">Price<span class="text-danger">*</span></label>
    <input type="text" name="price" placeholder="Please enter price" value="<?php echo e(!empty($product->price) ? $product->price : ''); ?>" class="form-control" aria-describedby="emailHelp">
</div>
<div class="mb-3">
    <label for="name" class="form-label">Qty<span class="text-danger">*</span></label>
    <input type="text" name="qty" placeholder="Please enter qty" value="<?php echo e(!empty($product->qty) ? $product->qty : ''); ?>" class="form-control" aria-describedby="emailHelp">
</div>
<div class="mb-3">
    <label for="category" class="form-label">Status <span class="text-danger">*</span></label>
    <select class="form-select" name="status">
        <option value="">Select</option`>
        <option value="active"  <?php echo e(( !empty($product) && $product->status == 'active') ? 'selected' : ''); ?>>Active</option>
        <option value="in_active" <?php echo e((!empty($product) && $product->status == 'in_active') ? 'selected' : ''); ?>>In-Active</option>
    </select>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-primary">Submit</button>
</div><?php /**PATH C:\xampp\htdocs\RLogicalTask\resources\views/product/form.blade.php ENDPATH**/ ?>